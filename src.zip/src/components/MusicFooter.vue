<template>
    <div>
        <footer id="footer">
            <h2>footer</h2>
                <div>
                    <ul>
                        <li>
                            <span>
                                <a herf="#"></a>
                            </span>
                        </li>
                    </ul>
                </div>
            
            <div>
            <span><span></span></span>
            <span><span></span></span>
            <span><span></span></span>
            </div>
            <div>
                <address>
                <span><span></span></span>
                <span><span></span></span>
                <span><span><a href=""></a></span></span>
                <span><span></span></span>
            </address>
            </div>
            <div>
                <a href="#"></a>
                <a href="#"></a>
                <a href="#"></a>
                <a href="#"></a>
                <a href="#"></a>
                <a href="#"></a>
                <a href="#"></a>
                <a href="#"></a>
            </div>
            <div>
                <a href="#"><span></span></a>
                <a href="#"><span></span></a>
                <a href="#"><span></span></a>
            </div>
        </footer>
        <div>
            <h2 class="blind">플레이어</h2>
        <div>
            <div>
                <a href="">
                    <img src="">
                        <span></span>
                </a>
            </div>
            </div>
        </div>
    </div>
</template>
  
<script>
import MusicContetnsVue from './MusicContents.vue'
import SectionContents from './SectionContents.vue'
import Section2Contents from './Section2Contents.vue'
export default {

}
</script>

<style>
* {
    margin:0;
    padding: 0;
}
.blind{
    display: none;
}
a {
    text-decoration: none;
    color: #000000;
}
v-ul li {
    list-style: none;
}
footer{
    width: 1550px;
    height: 400px;
    border: 2px solid slateblue;
    float: left;
}
</style>