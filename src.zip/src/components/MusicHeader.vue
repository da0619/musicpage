<template>
    <div id="wrap">
    <header id="header">
                <div class="header_wrap">
                    <div class="logo">
                        <h1 class="blind">로고</h1>
                        <a href="#">
                            <v-img src="../assets/image/siteLogo.jpg" style="width:150px;"></v-img>
                        </a>
                    </div>
                    <div class="header_contents">
                        <div class="login">
                            <a href="#">
                                <span>로그인</span>
                            </a>
                        </div>
                        <div class="membership">
                            <p>로그인하고 할인 멤버십 확인</p>
                            <a href="#"></a>
                        </div>
                        <div class="serach">
                            <span>
                                <input type="search" role="combobox" title="검색창" placeholder="Music 검색">
                                    <i class="fa-solid fa-magnifying-glass" style="color: #d8d4d4;"></i>
                                </input>
                            </span>
                            <a href="#"></a>
                        </div>
                        <div class="menu">
                            <v-ul>
                                <li>
                                    <a href="#">
                                        <span>투데이</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <span>차트</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <span>최신앨범</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <span>장르별 스테이션</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <span>VIBE MAG</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <span>이달의 노래</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <span>서비스안내</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <span>MY플레이</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <span>Magazine</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <span>뮤직비디오</span>
                                    </a>
                                </li>
                            </v-ul>
                        </div>
                        <div class="installation">

                        </div>
                    </div>
                </div>
            </header>
    </div>
</template>

<script>

export default {

}
</script>

<style scope>
* {
    margin:0;
    padding: 0;
}
header {
    background: #000000;
    width: 245px;
    height: 1900px;
    border: 3px solid red;
    display: block;
    position: fixed;
    float: left;
}
.blind{
    display: none;
}
a {
    text-decoration: none;
    color: #ffffff;
}
span, p {
    color : #ffffff;
}
v-ul li {
    list-style: none;
}
.serach input {
    border: 1px solid gary;
    background-color: rgba(230, 221, 221, 0.205);
    text-align: center;
    height: 28px;
    border-top-left-radius: 10%;
}
.serach {
    position: relative;
}
.fa-solid {
    position: absolute;
    left: 7px;
    bottom:5px;
    vertical-align: middle;
}
</style>
